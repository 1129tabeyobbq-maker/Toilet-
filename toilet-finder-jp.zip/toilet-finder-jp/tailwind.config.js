/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          blue: "#0A84FF",
          blueDark: "#0066CC",
          blueSoft: "#E8F2FF",
        },
      },
      borderRadius: {
        card: "20px",
      },
      boxShadow: {
        card: "0 2px 12px rgba(10, 132, 255, 0.08)",
      },
    },
  },
  plugins: [],
};
