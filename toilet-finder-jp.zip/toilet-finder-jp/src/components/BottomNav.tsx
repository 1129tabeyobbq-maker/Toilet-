"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const TABS = [
  { href: "/", label: "地図", icon: "🗺️" },
  { href: "/list", label: "リスト", icon: "📋" },
  { href: "/about", label: "このサイトについて", icon: "ℹ️" },
];

export default function BottomNav() {
  const pathname = usePathname();

  return (
    <nav className="z-30 flex shrink-0 border-t border-gray-100 bg-white/95 px-2 pb-[max(8px,env(safe-area-inset-bottom))] pt-2 backdrop-blur-md">
      {TABS.map((tab) => {
        const active = pathname === tab.href;
        return (
          <Link
            key={tab.href}
            href={tab.href}
            className="flex flex-1 flex-col items-center gap-0.5 rounded-xl py-1 text-[11px] transition-colors"
          >
            <span
              className={`text-[20px] leading-none ${
                active ? "" : "opacity-50"
              }`}
            >
              {tab.icon}
            </span>
            <span
              className={
                active
                  ? "font-semibold text-brand-blue"
                  : "font-medium text-gray-400"
              }
            >
              {tab.label}
            </span>
          </Link>
        );
      })}
    </nav>
  );
}
