"use client";

interface LocateButtonProps {
  onClick: () => void;
  loading: boolean;
}

export default function LocateButton({ onClick, loading }: LocateButtonProps) {
  return (
    <button
      onClick={onClick}
      disabled={loading}
      className="absolute bottom-4 left-4 z-20 flex items-center gap-2 rounded-full bg-white px-4 py-3 text-[14px] font-semibold text-brand-blue shadow-card active:bg-gray-50 disabled:opacity-60"
    >
      <span>{loading ? "取得中…" : "📍"}</span>
      <span>{loading ? "現在地を取得中" : "現在地に移動"}</span>
    </button>
  );
}
