"use client";

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  onFilterClick: () => void;
  activeFilterCount: number;
}

export default function SearchBar({
  value,
  onChange,
  onFilterClick,
  activeFilterCount,
}: SearchBarProps) {
  return (
    <div className="flex items-center gap-2 px-4 pt-3">
      <div className="flex flex-1 items-center gap-2 rounded-card bg-gray-100 px-3.5 py-2.5">
        <span className="text-gray-400">🔍</span>
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="施設名・駅名で検索"
          className="w-full bg-transparent text-[15px] outline-none placeholder:text-gray-400"
        />
      </div>
      <button
        onClick={onFilterClick}
        className="relative flex h-[42px] w-[42px] shrink-0 items-center justify-center rounded-card bg-gray-100 text-[18px] active:bg-gray-200"
        aria-label="フィルター"
      >
        ⚙️
        {activeFilterCount > 0 && (
          <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-brand-blue text-[10px] font-bold text-white">
            {activeFilterCount}
          </span>
        )}
      </button>
    </div>
  );
}
