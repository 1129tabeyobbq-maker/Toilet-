"use client";

import { CATEGORY_LABELS, ToiletSpot } from "@/lib/types";
import { distanceMeters, formatDistance, googleMapsLink, walkingMinutes } from "@/lib/geo";

interface ToiletDetailSheetProps {
  spot: ToiletSpot | null;
  userLocation: { lat: number; lon: number } | null;
  onClose: () => void;
}

export default function ToiletDetailSheet({
  spot,
  userLocation,
  onClose,
}: ToiletDetailSheetProps) {
  if (!spot) return null;

  const dist = userLocation
    ? distanceMeters(userLocation.lat, userLocation.lon, spot.lat, spot.lon)
    : null;

  return (
    <div className="fixed inset-0 z-40 flex items-end bg-black/30" onClick={onClose}>
      <div
        className="w-full rounded-t-[28px] bg-white p-5 pb-[max(20px,env(safe-area-inset-bottom))] shadow-card"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mb-4 h-1.5 w-10 rounded-full bg-gray-200" />

        <div className="mb-1 inline-block rounded-full bg-brand-blueSoft px-2.5 py-1 text-[12px] font-semibold text-brand-blue">
          {CATEGORY_LABELS[spot.category]}
        </div>
        <h2 className="mb-2 text-[19px] font-bold">{spot.name}</h2>

        {spot.address && (
          <p className="mb-1 text-[14px] text-gray-500">{spot.address}</p>
        )}

        <div className="mb-4 flex flex-wrap gap-3 text-[14px] text-gray-600">
          {dist !== null && (
            <span>
              📍 {formatDistance(dist)}（徒歩約{walkingMinutes(dist)}分）
            </span>
          )}
          {spot.is24h && <span>🕐 24時間</span>}
          {spot.wheelchair && <span>♿ 車椅子対応</span>}
          {spot.diaperTable && <span>🍼 オムツ交換台</span>}
        </div>

        <a
          href={googleMapsLink(spot.lat, spot.lon)}
          target="_blank"
          rel="noopener noreferrer"
          className="block w-full rounded-card bg-brand-blue py-3 text-center text-[16px] font-semibold text-white active:bg-brand-blueDark"
        >
          Googleマップで開く
        </a>
      </div>
    </div>
  );
}
