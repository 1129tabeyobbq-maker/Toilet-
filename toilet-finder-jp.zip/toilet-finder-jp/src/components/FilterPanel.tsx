"use client";

import {
  CATEGORY_LABELS,
  CategoryKey,
  ConditionKey,
  FilterState,
} from "@/lib/types";

interface FilterPanelProps {
  open: boolean;
  filters: FilterState;
  onChange: (filters: FilterState) => void;
  onClose: () => void;
}

const CONDITION_LABELS: Record<ConditionKey, string> = {
  "24h": "24時間利用可",
  wheelchair: "車椅子対応",
  diaper: "オムツ交換台あり",
};

export default function FilterPanel({
  open,
  filters,
  onChange,
  onClose,
}: FilterPanelProps) {
  if (!open) return null;

  const toggleCategory = (key: CategoryKey) => {
    onChange({
      ...filters,
      categories: { ...filters.categories, [key]: !filters.categories[key] },
    });
  };

  const toggleCondition = (key: ConditionKey) => {
    onChange({
      ...filters,
      conditions: { ...filters.conditions, [key]: !filters.conditions[key] },
    });
  };

  return (
    <div className="fixed inset-0 z-40 flex items-end bg-black/30" onClick={onClose}>
      <div
        className="w-full rounded-t-[28px] bg-white p-5 pb-[max(20px,env(safe-area-inset-bottom))] shadow-card"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mb-4 h-1.5 w-10 rounded-full bg-gray-200" />
        <h2 className="mb-3 text-[17px] font-bold">表示対象</h2>
        <div className="mb-5 flex flex-wrap gap-2">
          {(Object.keys(CATEGORY_LABELS) as CategoryKey[]).map((key) => {
            const active = filters.categories[key];
            return (
              <button
                key={key}
                onClick={() => toggleCategory(key)}
                className={`rounded-full px-4 py-2 text-[14px] font-medium transition-colors ${
                  active
                    ? "bg-brand-blue text-white"
                    : "bg-gray-100 text-gray-500"
                }`}
              >
                {CATEGORY_LABELS[key]}
              </button>
            );
          })}
        </div>

        <h2 className="mb-3 text-[17px] font-bold">条件</h2>
        <div className="mb-5 flex flex-wrap gap-2">
          {(Object.keys(CONDITION_LABELS) as ConditionKey[]).map((key) => {
            const active = filters.conditions[key];
            return (
              <button
                key={key}
                onClick={() => toggleCondition(key)}
                className={`rounded-full px-4 py-2 text-[14px] font-medium transition-colors ${
                  active
                    ? "bg-brand-blue text-white"
                    : "bg-gray-100 text-gray-500"
                }`}
              >
                {CONDITION_LABELS[key]}
              </button>
            );
          })}
        </div>

        <button
          onClick={onClose}
          className="w-full rounded-card bg-brand-blue py-3 text-[16px] font-semibold text-white active:bg-brand-blueDark"
        >
          適用する
        </button>
      </div>
    </div>
  );
}
