interface AdSlotProps {
  variant?: "inline" | "bottom";
  label?: string;
}

/**
 * Placeholder ad slot. Replace the inner div with the Google AdSense
 * <ins class="adsbygoogle"> tag once an AdSense account is approved,
 * and load the AdSense script in the root layout's <head>.
 */
export default function AdSlot({
  variant = "inline",
  label = "広告",
}: AdSlotProps) {
  return (
    <div
      className={
        variant === "bottom"
          ? "w-full border-t border-gray-100 bg-gray-50 px-4 py-2"
          : "my-3 w-full px-4"
      }
    >
      <div className="flex h-16 w-full items-center justify-center rounded-card border border-dashed border-gray-200 bg-gray-50 text-xs text-gray-400">
        {label}スペース
      </div>
    </div>
  );
}
