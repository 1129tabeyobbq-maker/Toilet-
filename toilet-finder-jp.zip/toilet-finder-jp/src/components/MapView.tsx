"use client";

import { useEffect, useRef } from "react";
import L from "leaflet";
import { CATEGORY_LABELS, ToiletSpot } from "@/lib/types";

interface MapViewProps {
  center: { lat: number; lon: number };
  userLocation: { lat: number; lon: number } | null;
  spots: ToiletSpot[];
  onMarkerClick: (spot: ToiletSpot) => void;
  onMapMoved: (center: { lat: number; lon: number }) => void;
}

const CATEGORY_COLORS: Record<string, string> = {
  public_toilet: "#0A84FF",
  convenience: "#34C759",
  station: "#FF9500",
  mall: "#AF52DE",
  gas_station: "#FF3B30",
};

function makeIcon(category: string) {
  const color = CATEGORY_COLORS[category] || "#0A84FF";
  return L.divIcon({
    className: "",
    html: `<div style="
      width:26px;height:26px;border-radius:50%;
      background:${color};border:2px solid white;
      box-shadow:0 1px 4px rgba(0,0,0,0.3);
      display:flex;align-items:center;justify-content:center;
      font-size:13px;color:white;">🚻</div>`,
    iconSize: [26, 26],
    iconAnchor: [13, 13],
  });
}

const USER_ICON = L.divIcon({
  className: "",
  html: `<div style="
    width:18px;height:18px;border-radius:50%;
    background:#0A84FF;border:3px solid white;
    box-shadow:0 0 0 4px rgba(10,132,255,0.25);"></div>`,
  iconSize: [18, 18],
  iconAnchor: [9, 9],
});

export default function MapView({
  center,
  userLocation,
  spots,
  onMarkerClick,
  onMapMoved,
}: MapViewProps) {
  const mapElRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);

  // Initialize map once
  useEffect(() => {
    if (!mapElRef.current || mapRef.current) return;

    const map = L.map(mapElRef.current, {
      center: [center.lat, center.lon],
      zoom: 16,
      zoomControl: false,
    });

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map);

    L.control.zoom({ position: "bottomright" }).addTo(map);

    markersLayerRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;

    let debounceTimer: ReturnType<typeof setTimeout> | null = null;
    map.on("moveend", () => {
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        const c = map.getCenter();
        onMapMoved({ lat: c.lat, lon: c.lng });
      }, 600);
    });

    return () => {
      map.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Recenter map when center prop changes externally (e.g. geolocation button)
  useEffect(() => {
    if (!mapRef.current) return;
    const current = mapRef.current.getCenter();
    const distMoved = current.distanceTo([center.lat, center.lon]);
    // Skip if the map is already (approximately) at this center — avoids
    // feeding back into itself from the map's own moveend event.
    if (distMoved < 5) return;
    mapRef.current.setView([center.lat, center.lon], mapRef.current.getZoom());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [center.lat, center.lon]);

  // Update user location marker
  useEffect(() => {
    if (!mapRef.current) return;
    if (userMarkerRef.current) {
      userMarkerRef.current.remove();
      userMarkerRef.current = null;
    }
    if (userLocation) {
      userMarkerRef.current = L.marker([userLocation.lat, userLocation.lon], {
        icon: USER_ICON,
        zIndexOffset: 1000,
      }).addTo(mapRef.current);
    }
  }, [userLocation]);

  // Update toilet markers
  useEffect(() => {
    if (!markersLayerRef.current) return;
    markersLayerRef.current.clearLayers();

    spots.forEach((spot) => {
      const marker = L.marker([spot.lat, spot.lon], {
        icon: makeIcon(spot.category),
      });
      marker.bindTooltip(
        `${spot.name}（${CATEGORY_LABELS[spot.category]}）`,
        { direction: "top", offset: [0, -10] }
      );
      marker.on("click", () => onMarkerClick(spot));
      markersLayerRef.current!.addLayer(marker);
    });
  }, [spots, onMarkerClick]);

  return <div ref={mapElRef} className="h-full w-full" />;
}
