import { ToiletSpot } from "./types";

const CACHE_KEY = "toilet-finder-jp:last-results";
const CACHE_CENTER_KEY = "toilet-finder-jp:last-center";

export function cacheResults(
  spots: ToiletSpot[],
  center: { lat: number; lon: number }
) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(spots));
    localStorage.setItem(CACHE_CENTER_KEY, JSON.stringify(center));
  } catch {
    // storage unavailable, ignore
  }
}

export function loadCachedResults(): {
  spots: ToiletSpot[];
  center: { lat: number; lon: number } | null;
} {
  try {
    const spotsRaw = localStorage.getItem(CACHE_KEY);
    const centerRaw = localStorage.getItem(CACHE_CENTER_KEY);
    return {
      spots: spotsRaw ? JSON.parse(spotsRaw) : [],
      center: centerRaw ? JSON.parse(centerRaw) : null,
    };
  } catch {
    return { spots: [], center: null };
  }
}
