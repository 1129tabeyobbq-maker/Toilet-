export type CategoryKey =
  | "public_toilet"
  | "convenience"
  | "station"
  | "mall"
  | "gas_station";

export type ConditionKey = "24h" | "wheelchair" | "diaper";

export interface ToiletSpot {
  id: string;
  name: string;
  category: CategoryKey;
  lat: number;
  lon: number;
  address?: string;
  openingHours?: string;
  wheelchair?: boolean;
  diaperTable?: boolean;
  is24h: boolean;
}

export interface FilterState {
  categories: Record<CategoryKey, boolean>;
  conditions: Record<ConditionKey, boolean>;
}

export const CATEGORY_LABELS: Record<CategoryKey, string> = {
  public_toilet: "公衆トイレ",
  convenience: "コンビニ",
  station: "駅",
  mall: "商業施設",
  gas_station: "ガソリンスタンド",
};

export const DEFAULT_FILTER_STATE: FilterState = {
  categories: {
    public_toilet: true,
    convenience: true,
    station: true,
    mall: true,
    gas_station: true,
  },
  conditions: {
    "24h": false,
    wheelchair: false,
    diaper: false,
  },
};
