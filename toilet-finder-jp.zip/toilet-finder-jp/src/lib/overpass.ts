import { CategoryKey, FilterState, ToiletSpot } from "./types";

const OVERPASS_ENDPOINT = "https://overpass-api.de/api/interpreter";

/**
 * Build an Overpass QL query that fetches toilets and toilet-bearing
 * facilities (convenience stores, stations, malls, gas stations) within
 * a given radius (meters) of a center point.
 */
function buildQuery(lat: number, lon: number, radiusM: number): string {
  return `
[out:json][timeout:25];
(
  node["amenity"="toilets"](around:${radiusM},${lat},${lon});
  way["amenity"="toilets"](around:${radiusM},${lat},${lon});
  node["shop"="convenience"](around:${radiusM},${lat},${lon});
  node["railway"="station"](around:${radiusM},${lat},${lon});
  node["railway"="subway_entrance"](around:${radiusM},${lat},${lon});
  node["shop"="mall"](around:${radiusM},${lat},${lon});
  way["shop"="mall"](around:${radiusM},${lat},${lon});
  node["amenity"="fuel"](around:${radiusM},${lat},${lon});
);
out center;
`;
}

function categorize(tags: Record<string, string>): CategoryKey | null {
  if (tags.amenity === "toilets") return "public_toilet";
  if (tags.shop === "convenience") return "convenience";
  if (tags.railway === "station" || tags.railway === "subway_entrance")
    return "station";
  if (tags.shop === "mall") return "mall";
  if (tags.amenity === "fuel") return "gas_station";
  return null;
}

function buildAddress(tags: Record<string, string>): string | undefined {
  const pref = tags["addr:province"] || tags["addr:state"];
  const city = tags["addr:city"];
  const ward = tags["addr:suburb"] || tags["addr:district"];
  const block = tags["addr:block_number"] || tags["addr:neighbourhood"];
  const housenumber = tags["addr:housenumber"];
  const parts = [pref, city, ward, block, housenumber].filter(Boolean);
  return parts.length > 0 ? parts.join("") : undefined;
}

interface OverpassElement {
  type: string;
  id: number;
  lat?: number;
  lon?: number;
  center?: { lat: number; lon: number };
  tags?: Record<string, string>;
}

export async function fetchToiletsNearby(
  lat: number,
  lon: number,
  radiusM = 2000
): Promise<ToiletSpot[]> {
  const query = buildQuery(lat, lon, radiusM);
  const res = await fetch(OVERPASS_ENDPOINT, {
    method: "POST",
    body: "data=" + encodeURIComponent(query),
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
  });

  if (!res.ok) {
    throw new Error(`Overpass API error: ${res.status}`);
  }

  const data: { elements: OverpassElement[] } = await res.json();

  const spots: ToiletSpot[] = [];

  for (const el of data.elements) {
    const tags = el.tags || {};
    const category = categorize(tags);
    if (!category) continue;

    const elLat = el.lat ?? el.center?.lat;
    const elLon = el.lon ?? el.center?.lon;
    if (elLat === undefined || elLon === undefined) continue;

    const name =
      tags.name ||
      (category === "public_toilet"
        ? "公衆トイレ"
        : category === "convenience"
        ? "コンビニ"
        : category === "station"
        ? "駅"
        : category === "mall"
        ? "商業施設"
        : "ガソリンスタンド");

    const openingHours = tags.opening_hours;
    const is24h =
      openingHours === "24/7" ||
      tags.amenity === "fuel" ||
      category === "convenience";

    spots.push({
      id: `${el.type}/${el.id}`,
      name,
      category,
      lat: elLat,
      lon: elLon,
      address: buildAddress(tags),
      openingHours,
      wheelchair: tags.wheelchair === "yes",
      diaperTable:
        tags["changing_table"] === "yes" || tags["diaper"] === "yes",
      is24h,
    });
  }

  return spots;
}

export function applyFilters(
  spots: ToiletSpot[],
  filters: FilterState
): ToiletSpot[] {
  return spots.filter((spot) => {
    if (!filters.categories[spot.category]) return false;
    if (filters.conditions["24h"] && !spot.is24h) return false;
    if (filters.conditions.wheelchair && !spot.wheelchair) return false;
    if (filters.conditions.diaper && !spot.diaperTable) return false;
    return true;
  });
}
