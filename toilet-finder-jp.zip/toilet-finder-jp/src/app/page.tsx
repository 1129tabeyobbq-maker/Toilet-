"use client";

import dynamic from "next/dynamic";
import { useCallback, useMemo, useState } from "react";
import SearchBar from "@/components/SearchBar";
import FilterPanel from "@/components/FilterPanel";
import LocateButton from "@/components/LocateButton";
import ToiletDetailSheet from "@/components/ToiletDetailSheet";
import AdSlot from "@/components/AdSlot";
import { applyFilters, fetchToiletsNearby } from "@/lib/overpass";
import { cacheResults, loadCachedResults } from "@/lib/cache";
import { DEFAULT_FILTER_STATE, FilterState, ToiletSpot } from "@/lib/types";

const MapView = dynamic(() => import("@/components/MapView"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full items-center justify-center text-gray-400">
      地図を読み込み中…
    </div>
  ),
});

// Default to Tokyo Station if geolocation isn't available yet
const DEFAULT_CENTER = { lat: 35.681236, lon: 139.767125 };

export default function HomePage() {
  const [center, setCenter] = useState(DEFAULT_CENTER);
  const [userLocation, setUserLocation] = useState<
    { lat: number; lon: number } | null
  >(null);
  const [spots, setSpots] = useState<ToiletSpot[]>([]);
  const [query, setQuery] = useState("");
  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTER_STATE);
  const [filterOpen, setFilterOpen] = useState(false);
  const [selectedSpot, setSelectedSpot] = useState<ToiletSpot | null>(null);
  const [locating, setLocating] = useState(false);
  const [loadingSpots, setLoadingSpots] = useState(false);
  const [isOffline, setIsOffline] = useState(false);

  const search = useCallback(async (lat: number, lon: number) => {
    setLoadingSpots(true);
    try {
      const results = await fetchToiletsNearby(lat, lon, 2000);
      setSpots(results);
      cacheResults(results, { lat, lon });
      setIsOffline(false);
    } catch (err) {
      console.error(err);
      const cached = loadCachedResults();
      if (cached.spots.length > 0) {
        setSpots(cached.spots);
        setIsOffline(true);
      }
    } finally {
      setLoadingSpots(false);
    }
  }, []);

  const handleLocate = useCallback(() => {
    if (!navigator.geolocation) {
      alert("お使いの端末では位置情報を取得できません。");
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const loc = { lat: pos.coords.latitude, lon: pos.coords.longitude };
        setUserLocation(loc);
        setCenter(loc);
        search(loc.lat, loc.lon);
        setLocating(false);
      },
      () => {
        alert("位置情報の取得が許可されませんでした。設定をご確認ください。");
        setLocating(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }, [search]);

  const handleMapMoved = useCallback(
    (newCenter: { lat: number; lon: number }) => {
      setCenter(newCenter);
      search(newCenter.lat, newCenter.lon);
    },
    [search]
  );

  const filteredSpots = useMemo(() => {
    const byFilter = applyFilters(spots, filters);
    if (!query.trim()) return byFilter;
    const q = query.trim().toLowerCase();
    return byFilter.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        (s.address || "").toLowerCase().includes(q)
    );
  }, [spots, filters, query]);

  const activeFilterCount = useMemo(() => {
    const catCount = Object.values(filters.categories).filter((v) => !v)
      .length; // count disabled categories as "changed from default"
    const condCount = Object.values(filters.conditions).filter(Boolean)
      .length;
    return catCount + condCount;
  }, [filters]);

  return (
    <div className="relative flex h-full flex-col">
      <SearchBar
        value={query}
        onChange={setQuery}
        onFilterClick={() => setFilterOpen(true)}
        activeFilterCount={activeFilterCount}
      />

      {isOffline && (
        <div className="mx-4 mt-2 rounded-card bg-yellow-50 px-3 py-2 text-[12px] text-yellow-700">
          オフラインのため、前回取得したデータを表示しています。
        </div>
      )}

      <div className="relative mt-3 flex-1 overflow-hidden">
        <MapView
          center={center}
          userLocation={userLocation}
          spots={filteredSpots}
          onMarkerClick={setSelectedSpot}
          onMapMoved={handleMapMoved}
        />
        <LocateButton onClick={handleLocate} loading={locating} />
        {loadingSpots && (
          <div className="absolute right-4 top-4 z-20 rounded-full bg-white px-3 py-1.5 text-[12px] text-gray-500 shadow-card">
            周辺のトイレを検索中…
          </div>
        )}
      </div>

      <AdSlot variant="bottom" />

      <FilterPanel
        open={filterOpen}
        filters={filters}
        onChange={setFilters}
        onClose={() => setFilterOpen(false)}
      />

      <ToiletDetailSheet
        spot={selectedSpot}
        userLocation={userLocation}
        onClose={() => setSelectedSpot(null)}
      />
    </div>
  );
}
