import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "このサイトについて",
  description:
    "トイレファインダーJPは、現在地周辺のトイレを地図でかんたんに検索できる無料サービスです。登録不要、OpenStreetMapのデータを利用しています。",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <div className="h-full overflow-y-auto px-5 py-6">
      <h1 className="mb-4 text-[20px] font-bold">このサイトについて</h1>

      <section className="mb-5 rounded-card border border-gray-100 bg-white p-4 shadow-card">
        <h2 className="mb-2 text-[16px] font-bold">トイレファインダーJPとは</h2>
        <p className="text-[14px] leading-relaxed text-gray-600">
          現在地周辺の公衆トイレ・コンビニ・駅・商業施設・ガソリンスタンドのトイレ情報を地図上に表示する無料サービスです。会員登録やログインは不要で、ブラウザからすぐにご利用いただけます。
        </p>
      </section>

      <section className="mb-5 rounded-card border border-gray-100 bg-white p-4 shadow-card">
        <h2 className="mb-2 text-[16px] font-bold">データについて</h2>
        <p className="text-[14px] leading-relaxed text-gray-600">
          地図データおよびトイレ情報は OpenStreetMap のコントリビューターによって提供されています。情報は最新でない場合や、実際の状況と異なる場合がありますので、あくまでも参考情報としてご利用ください。
        </p>
      </section>

      <section className="rounded-card border border-gray-100 bg-white p-4 shadow-card">
        <h2 className="mb-2 text-[16px] font-bold">位置情報の利用について</h2>
        <p className="text-[14px] leading-relaxed text-gray-600">
          現在地情報は周辺のトイレ検索のみに使用され、サーバーに保存されることはありません。位置情報の利用を許可しなくても地図の閲覧は可能です。
        </p>
      </section>
    </div>
  );
}
