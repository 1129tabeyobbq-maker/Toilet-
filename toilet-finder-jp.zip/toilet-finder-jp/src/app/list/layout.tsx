import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "周辺のトイレ一覧",
  description: "現在地周辺のトイレを距離が近い順に一覧表示します。",
  alternates: { canonical: "/list" },
};

export default function ListLayout({ children }: { children: React.ReactNode }) {
  return children;
}
