"use client";

import { Fragment, useCallback, useEffect, useMemo, useState } from "react";
import AdSlot from "@/components/AdSlot";
import ToiletDetailSheet from "@/components/ToiletDetailSheet";
import { fetchToiletsNearby, applyFilters } from "@/lib/overpass";
import { loadCachedResults, cacheResults } from "@/lib/cache";
import { distanceMeters, formatDistance, walkingMinutes } from "@/lib/geo";
import { CATEGORY_LABELS, DEFAULT_FILTER_STATE, ToiletSpot } from "@/lib/types";

export default function ListPage() {
  const [spots, setSpots] = useState<ToiletSpot[]>([]);
  const [userLocation, setUserLocation] = useState<
    { lat: number; lon: number } | null
  >(null);
  const [selectedSpot, setSelectedSpot] = useState<ToiletSpot | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async (lat: number, lon: number) => {
    setLoading(true);
    try {
      const results = await fetchToiletsNearby(lat, lon, 2000);
      setSpots(results);
      cacheResults(results, { lat, lon });
    } catch {
      const cached = loadCachedResults();
      setSpots(cached.spots);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!navigator.geolocation) {
      const cached = loadCachedResults();
      setSpots(cached.spots);
      setLoading(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const loc = { lat: pos.coords.latitude, lon: pos.coords.longitude };
        setUserLocation(loc);
        load(loc.lat, loc.lon);
      },
      () => {
        const cached = loadCachedResults();
        setSpots(cached.spots);
        setLoading(false);
      }
    );
  }, [load]);

  const sortedSpots = useMemo(() => {
    const filtered = applyFilters(spots, DEFAULT_FILTER_STATE);
    if (!userLocation) return filtered;
    return [...filtered].sort(
      (a, b) =>
        distanceMeters(userLocation.lat, userLocation.lon, a.lat, a.lon) -
        distanceMeters(userLocation.lat, userLocation.lon, b.lat, b.lon)
    );
  }, [spots, userLocation]);

  return (
    <div className="flex h-full flex-col overflow-y-auto px-4 pb-6 pt-4">
      <h1 className="mb-3 text-[20px] font-bold">周辺のトイレ</h1>

      {loading && (
        <p className="py-8 text-center text-[14px] text-gray-400">
          読み込み中…
        </p>
      )}

      {!loading && sortedSpots.length === 0 && (
        <p className="py-8 text-center text-[14px] text-gray-400">
          周辺にトイレが見つかりませんでした。
        </p>
      )}

      <div className="flex flex-col gap-3">
        {sortedSpots.slice(0, 6).map((spot, idx) => (
          <Fragment key={spot.id}>
            <button
              onClick={() => setSelectedSpot(spot)}
              className="rounded-card border border-gray-100 bg-white p-4 text-left shadow-card active:bg-gray-50"
            >
              <div className="mb-1 inline-block rounded-full bg-brand-blueSoft px-2 py-0.5 text-[11px] font-semibold text-brand-blue">
                {CATEGORY_LABELS[spot.category]}
              </div>
              <h2 className="text-[16px] font-bold">{spot.name}</h2>
              {spot.address && (
                <p className="text-[13px] text-gray-500">{spot.address}</p>
              )}
              {userLocation && (
                <p className="mt-1 text-[13px] text-gray-600">
                  📍{" "}
                  {formatDistance(
                    distanceMeters(
                      userLocation.lat,
                      userLocation.lon,
                      spot.lat,
                      spot.lon
                    )
                  )}
                  （徒歩約
                  {walkingMinutes(
                    distanceMeters(
                      userLocation.lat,
                      userLocation.lon,
                      spot.lat,
                      spot.lon
                    )
                  )}
                  分）
                </p>
              )}
            </button>
            {idx === 2 && <AdSlot key={`${spot.id}-ad`} />}
          </Fragment>
        ))}
        {sortedSpots.slice(6).map((spot) => (
          <button
            key={spot.id}
            onClick={() => setSelectedSpot(spot)}
            className="rounded-card border border-gray-100 bg-white p-4 text-left shadow-card active:bg-gray-50"
          >
            <div className="mb-1 inline-block rounded-full bg-brand-blueSoft px-2 py-0.5 text-[11px] font-semibold text-brand-blue">
              {CATEGORY_LABELS[spot.category]}
            </div>
            <h2 className="text-[16px] font-bold">{spot.name}</h2>
            {spot.address && (
              <p className="text-[13px] text-gray-500">{spot.address}</p>
            )}
          </button>
        ))}
      </div>

      <ToiletDetailSheet
        spot={selectedSpot}
        userLocation={userLocation}
        onClose={() => setSelectedSpot(null)}
      />
    </div>
  );
}
