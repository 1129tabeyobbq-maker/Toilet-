import type { Metadata, Viewport } from "next";
import "./globals.css";
import "leaflet/dist/leaflet.css";
import BottomNav from "@/components/BottomNav";
import ServiceWorkerRegister from "@/components/ServiceWorkerRegister";

const SITE_URL = "https://toilet-finder-jp.vercel.app";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "トイレファインダーJP | 現在地周辺のトイレ検索",
    template: "%s | トイレファインダーJP",
  },
  description:
    "現在地周辺の公衆トイレ・コンビニ・駅・商業施設・ガソリンスタンドのトイレを地図でかんたん検索。登録不要、無料で今すぐ使えます。",
  keywords: [
    "トイレ検索",
    "公衆トイレ",
    "現在地",
    "トイレマップ",
    "コンビニ トイレ",
  ],
  applicationName: "トイレファインダーJP",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: "/icons/icon-192.png",
    apple: "/icons/icon-192.png",
  },
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "トイレファインダーJP | 現在地周辺のトイレ検索",
    description:
      "現在地周辺の公衆トイレ・コンビニ・駅・商業施設・ガソリンスタンドのトイレを地図でかんたん検索。",
    url: SITE_URL,
    siteName: "トイレファインダーJP",
    locale: "ja_JP",
    type: "website",
  },
  twitter: {
    card: "summary",
    title: "トイレファインダーJP",
    description: "現在地周辺のトイレを地図でかんたん検索。",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#0A84FF",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ja">
      <body className="flex h-dvh flex-col overflow-hidden bg-white">
        <ServiceWorkerRegister />
        <main className="flex-1 overflow-hidden">{children}</main>
        <BottomNav />
      </body>
    </html>
  );
}
