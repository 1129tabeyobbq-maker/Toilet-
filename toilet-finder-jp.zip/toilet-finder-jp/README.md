# トイレファインダーJP（Web版）

現在地周辺のトイレを地図でかんたんに検索できる、登録不要のスマホ向けWebサービスです。

## 技術構成

- Next.js 14（App Router）/ TypeScript
- Tailwind CSS
- Leaflet + OpenStreetMap タイル
- Overpass API（トイレ・コンビニ・駅・商業施設・ガソリンスタンドのデータ取得）
- PWA対応（manifest / Service Worker）

## セットアップ

```bash
npm install
npm run dev
```

`http://localhost:3000` で確認できます。

## ディレクトリ構成

```
src/
  app/
    page.tsx          トップページ（地図・検索・フィルター）
    list/page.tsx      リスト表示ページ
    about/page.tsx      サイトについて
    robots.ts / sitemap.ts  SEO
  components/
    MapView.tsx         Leaflet地図（クライアント限定）
    SearchBar.tsx        検索バー
    FilterPanel.tsx      フィルターパネル（下部シート）
    ToiletDetailSheet.tsx  トイレ詳細（下部シート）
    LocateButton.tsx     現在地取得ボタン
    AdSlot.tsx          広告スペース（プレースホルダー）
    BottomNav.tsx        下部固定メニュー
  lib/
    overpass.ts         Overpass APIクエリ・データ整形
    geo.ts              距離・徒歩時間・Googleマップリンク計算
    cache.ts            オフライン用のlocalStorageキャッシュ
    types.ts            型定義
public/
  manifest.webmanifest  PWAマニフェスト
  sw.js               Service Worker
  icons/              PWAアイコン
```

## 広告（Google AdSense）について

`src/components/AdSlot.tsx` はプレースホルダーです。AdSenseの審査が完了したら、
1. `src/app/layout.tsx` の `<head>` にAdSenseの読み込みスクリプトを追加
2. `AdSlot.tsx` 内のプレースホルダーdivを `<ins class="adsbygoogle">` タグに置き換え

してください。

## デプロイ（Vercel）

1. このリポジトリをGitHubにpush
2. [Vercel](https://vercel.com) で「Import Project」からリポジトリを選択
3. ビルド設定はデフォルト（Next.jsを自動検出）のままデプロイ可能

デプロイ後、`src/app/layout.tsx` と `src/app/sitemap.ts` / `src/app/robots.ts` 内の
`SITE_URL` を実際の本番URLに置き換えてください。

## 注意事項

- Overpass APIは公開のレート制限付きAPIです。アクセスが多い場合は専用のOverpassサーバーや
  キャッシュ層の導入を検討してください。
- 現在地情報はブラウザ内でのみ使用され、サーバーには送信・保存されません。
- アイコン画像（`public/icons/`）と `public/favicon.ico` は仮のプレースホルダーです。
  本番公開前に正式なブランドアイコンに差し替えてください。

## 将来の拡張案（指示書より）

レビュー機能、写真投稿、お気に入り、利用成功率、混雑度、ログイン機能、管理画面。
これらは現バージョンには含まれていません。
